package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"spiderman-terminal/frames"
)

const (
	frameDelay = 115 * time.Millisecond
	clearANSI  = "\x1b[2J\x1b[H"
	resetANSI  = "\x1b[0m"
)

func homeHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	fmt.Fprintln(w, "SPIDER-MAN: BLACK SUIT DANCE")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Run this from a terminal:")
	fmt.Fprintln(w, "  curl -N https://YOUR-HOST/spiderman")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Available animation route: /spiderman")
}

func animationHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/spiderman" && r.URL.Path != "/spider-man" && r.URL.Path != "/black-suit-dance" {
		http.NotFound(w, r)
		return
	}

	// Browsers buffer plain text differently; this endpoint is designed for curl.
	if !strings.Contains(strings.ToLower(r.UserAgent()), "curl") {
		http.Error(w, "This animation is intended to be viewed with curl in a terminal.\n", http.StatusExpectationFailed)
		return
	}

	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "Streaming is not supported by this server.\n", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("Cache-Control", "no-cache, no-store, must-revalidate")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	flusher.Flush()

	ticker := time.NewTicker(frameDelay)
	defer ticker.Stop()

	frameIndex := 0
	for {
		select {
		case <-r.Context().Done():
			return
		case <-ticker.C:
			if _, err := fmt.Fprint(w, clearANSI, frames.FrameAt(frameIndex), resetANSI); err != nil {
				return // client disconnected
			}
			flusher.Flush()
			frameIndex = (frameIndex + 1) % frames.FrameCount()
		}
	}
}

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/", homeHandler)
	mux.HandleFunc("/spiderman", animationHandler)
	mux.HandleFunc("/spider-man", animationHandler)
	mux.HandleFunc("/black-suit-dance", animationHandler)

	server := &http.Server{
		Addr:              ":" + port,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}

	log.Printf("Spider-Man terminal animation server listening on :%s", port)
	log.Fatal(server.ListenAndServe())
}
