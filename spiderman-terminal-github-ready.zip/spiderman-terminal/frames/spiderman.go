// Package frames builds the original black-suit Spider-Man dance animation.
// The character and choreography are an ASCII interpretation, not traced
// frames from the Spider-Man 3 film.
package frames

import (
	"fmt"
	"math"
	"strings"
)

const (
	canvasW = 68
	canvasH = 29
)

type point struct{ x, y float64 }

type pose struct {
	head                 point
	shoulderL, shoulderR point
	elbowL, elbowR       point
	wristL, wristR       point
	hipL, hipR           point
	kneeL, kneeR         point
	ankleL, ankleR       point
}

// Eight key poses make a looping, original dance sequence. Intermediate
// frames are interpolated to avoid the stop-motion look of a tiny frame list.
var keyPoses = []pose{
	{
		head: point{33, 5}, shoulderL: point{27, 10}, shoulderR: point{39, 10},
		elbowL: point{23, 14}, elbowR: point{43, 13}, wristL: point{21, 18}, wristR: point{46, 17},
		hipL: point{29, 18}, hipR: point{37, 18}, kneeL: point{27, 23}, kneeR: point{40, 23},
		ankleL: point{25, 27}, ankleR: point{42, 27},
	},
	{
		head: point{33, 5}, shoulderL: point{27, 10}, shoulderR: point{39, 10},
		elbowL: point{21, 10}, elbowR: point{43, 14}, wristL: point{15, 8}, wristR: point{46, 18},
		hipL: point{29, 18}, hipR: point{37, 18}, kneeL: point{26, 23}, kneeR: point{40, 22},
		ankleL: point{23, 27}, ankleR: point{43, 27},
	},
	{
		head: point{34, 5}, shoulderL: point{28, 10}, shoulderR: point{40, 10},
		elbowL: point{23, 13}, elbowR: point{45, 8}, wristL: point{29, 15}, wristR: point{49, 4},
		hipL: point{30, 18}, hipR: point{38, 18}, kneeL: point{27, 22}, kneeR: point{41, 24},
		ankleL: point{24, 27}, ankleR: point{44, 27},
	},
	{
		head: point{33, 5}, shoulderL: point{27, 10}, shoulderR: point{39, 10},
		elbowL: point{21, 7}, elbowR: point{44, 7}, wristL: point{17, 3}, wristR: point{48, 3},
		hipL: point{29, 18}, hipR: point{37, 18}, kneeL: point{26, 23}, kneeR: point{40, 23},
		ankleL: point{24, 27}, ankleR: point{42, 27},
	},
	{
		head: point{32, 5}, shoulderL: point{26, 10}, shoulderR: point{38, 10},
		elbowL: point{21, 13}, elbowR: point{42, 13}, wristL: point{18, 17}, wristR: point{35, 15},
		hipL: point{28, 18}, hipR: point{36, 18}, kneeL: point{25, 22}, kneeR: point{39, 24},
		ankleL: point{23, 27}, ankleR: point{43, 27},
	},
	{
		head: point{33, 5}, shoulderL: point{27, 10}, shoulderR: point{39, 10},
		elbowL: point{22, 7}, elbowR: point{43, 13}, wristL: point{25, 3}, wristR: point{46, 16},
		hipL: point{29, 18}, hipR: point{37, 18}, kneeL: point{27, 24}, kneeR: point{39, 22},
		ankleL: point{25, 27}, ankleR: point{42, 27},
	},
	{
		head: point{34, 5}, shoulderL: point{28, 10}, shoulderR: point{40, 10},
		elbowL: point{22, 13}, elbowR: point{44, 10}, wristL: point{28, 16}, wristR: point{49, 7},
		hipL: point{30, 18}, hipR: point{38, 18}, kneeL: point{28, 22}, kneeR: point{42, 24},
		ankleL: point{26, 27}, ankleR: point{45, 27},
	},
	{
		head: point{33, 5}, shoulderL: point{27, 10}, shoulderR: point{39, 10},
		elbowL: point{21, 8}, elbowR: point{43, 8}, wristL: point{17, 4}, wristR: point{47, 4},
		hipL: point{29, 18}, hipR: point{37, 18}, kneeL: point{26, 23}, kneeR: point{40, 23},
		ankleL: point{24, 27}, ankleR: point{42, 27},
	},
}

func mix(a, b point, t float64) point {
	return point{x: a.x + (b.x-a.x)*t, y: a.y + (b.y-a.y)*t}
}

func mixPose(a, b pose, t float64) pose {
	return pose{
		head:      mix(a.head, b.head, t),
		shoulderL: mix(a.shoulderL, b.shoulderL, t), shoulderR: mix(a.shoulderR, b.shoulderR, t),
		elbowL: mix(a.elbowL, b.elbowL, t), elbowR: mix(a.elbowR, b.elbowR, t),
		wristL: mix(a.wristL, b.wristL, t), wristR: mix(a.wristR, b.wristR, t),
		hipL: mix(a.hipL, b.hipL, t), hipR: mix(a.hipR, b.hipR, t),
		kneeL: mix(a.kneeL, b.kneeL, t), kneeR: mix(a.kneeR, b.kneeR, t),
		ankleL: mix(a.ankleL, b.ankleL, t), ankleR: mix(a.ankleR, b.ankleR, t),
	}
}

type canvas [][]rune

func newCanvas() canvas {
	c := make(canvas, canvasH)
	for y := range c {
		c[y] = []rune(strings.Repeat(" ", canvasW))
	}
	return c
}

func (c canvas) put(x, y int, ch rune) {
	if x >= 0 && x < canvasW && y >= 0 && y < canvasH && ch != ' ' {
		c[y][x] = ch
	}
}

func (c canvas) disk(x, y, radius int, ch rune) {
	for dy := -radius; dy <= radius; dy++ {
		for dx := -radius; dx <= radius; dx++ {
			if dx*dx+dy*dy <= radius*radius {
				c.put(x+dx, y+dy, ch)
			}
		}
	}
}

func (c canvas) line(a, b point, radius int, ch rune) {
	dx, dy := b.x-a.x, b.y-a.y
	steps := int(math.Max(math.Abs(dx), math.Abs(dy)) * 2)
	if steps < 1 {
		steps = 1
	}
	for i := 0; i <= steps; i++ {
		t := float64(i) / float64(steps)
		c.disk(int(math.Round(a.x+dx*t)), int(math.Round(a.y+dy*t)), radius, ch)
	}
}

func insidePolygon(x, y int, poly []point) bool {
	inside := false
	j := len(poly) - 1
	for i := 0; i < len(poly); i++ {
		xi, yi := poly[i].x, poly[i].y
		xj, yj := poly[j].x, poly[j].y
		if (yi > float64(y)) != (yj > float64(y)) &&
			float64(x) < (xj-xi)*(float64(y)-yi)/(yj-yi)+xi {
			inside = !inside
		}
		j = i
	}
	return inside
}

func (c canvas) polygon(poly []point, ch rune) {
	minX, maxX := canvasW, 0
	minY, maxY := canvasH, 0
	for _, p := range poly {
		x, y := int(math.Round(p.x)), int(math.Round(p.y))
		if x < minX {
			minX = x
		}
		if x > maxX {
			maxX = x
		}
		if y < minY {
			minY = y
		}
		if y > maxY {
			maxY = y
		}
	}
	for y := minY; y <= maxY; y++ {
		for x := minX; x <= maxX; x++ {
			if insidePolygon(x, y, poly) {
				c.put(x, y, ch)
			}
		}
	}
}

func drawLimb(c canvas, a, b point) {
	c.line(a, b, 2, '@') // subtle outer silhouette/highlight
	c.line(a, b, 1, '#') // suit body
	c.line(mix(a, b, .45), mix(a, b, .55), 0, 'R')
}

func render(p pose, phase int) string {
	c := newCanvas()

	// Distant stage lights and a floor baseline.
	for y := 1; y < canvasH-1; y++ {
		if y%4 == 0 {
			c.put(5+(phase%3), y, '.')
			c.put(61-(phase%3), y, '.')
		}
	}
	for x := 7; x < canvasW-7; x++ {
		if x%3 == 0 {
			c.put(x, 28, '.')
		}
	}

	// Legs first, so the torso naturally overlaps their upper ends.
	drawLimb(c, p.hipL, p.kneeL)
	drawLimb(c, p.kneeL, p.ankleL)
	drawLimb(c, p.hipR, p.kneeR)
	drawLimb(c, p.kneeR, p.ankleR)

	// Arms sit behind the chest.
	drawLimb(c, p.shoulderL, p.elbowL)
	drawLimb(c, p.elbowL, p.wristL)
	drawLimb(c, p.shoulderR, p.elbowR)
	drawLimb(c, p.elbowR, p.wristR)

	// Broad, tapered torso.
	torso := []point{p.shoulderL, p.shoulderR, p.hipR, p.hipL}
	c.polygon(torso, '@')
	inner := []point{
		mix(p.shoulderL, p.hipL, .15), mix(p.shoulderR, p.hipR, .15),
		mix(p.hipR, p.shoulderR, .15), mix(p.hipL, p.shoulderL, .15),
	}
	c.polygon(inner, '#')

	// Red piping along the shoulders and outer torso adds a restrained suit accent.
	c.line(p.shoulderL, mix(p.hipL, p.shoulderL, .35), 0, 'R')
	c.line(p.shoulderR, mix(p.hipR, p.shoulderR, .35), 0, 'R')

	// Spider emblem on the chest.
	chest := mix(mix(p.shoulderL, p.shoulderR, .5), mix(p.hipL, p.hipR, .5), .38)
	cx, cy := int(math.Round(chest.x)), int(math.Round(chest.y))
	c.put(cx, cy, '*')
	c.put(cx-1, cy+1, '*')
	c.put(cx+1, cy+1, '*')
	c.put(cx-2, cy+2, '.')
	c.put(cx+2, cy+2, '.')

	// Wrist and ankle shapes give the silhouette clearer endpoints.
	c.disk(int(math.Round(p.wristL.x)), int(math.Round(p.wristL.y)), 1, '#')
	c.disk(int(math.Round(p.wristR.x)), int(math.Round(p.wristR.y)), 1, '#')
	c.line(p.ankleL, point{p.ankleL.x - 2, p.ankleL.y}, 1, '#')
	c.line(p.ankleR, point{p.ankleR.x + 2, p.ankleR.y}, 1, '#')

	// Mask: charcoal rim, black face, then the two bright eye lenses.
	hx, hy := int(math.Round(p.head.x)), int(math.Round(p.head.y))
	c.disk(hx, hy, 4, '@')
	c.disk(hx, hy, 3, '#')
	c.line(point{float64(hx - 2), float64(hy - 1)}, point{float64(hx - 1), float64(hy)}, 0, 'W')
	c.line(point{float64(hx + 1), float64(hy)}, point{float64(hx + 2), float64(hy - 1)}, 0, 'W')
	c.put(hx, hy+2, '.')

	// Convert the raster into ANSI-coloured terminal text.
	var out strings.Builder
	for _, row := range c {
		for _, ch := range row {
			switch ch {
			case '#':
				out.WriteString("\x1b[38;2;20;22;31m")
			case '@':
				out.WriteString("\x1b[38;2;91;98;116m")
			case 'R':
				out.WriteString("\x1b[38;2;175;42;58m")
			case 'W':
				out.WriteString("\x1b[38;2;245;247;255m")
			case '*':
				out.WriteString("\x1b[38;2;220;225;238m")
			case '.':
				out.WriteString("\x1b[38;2;76;85;105m")
			}
			out.WriteRune(ch)
			if ch != ' ' {
				out.WriteString("\x1b[0m")
			}
		}
		out.WriteByte('\n')
	}
	return out.String()
}

// SpiderMan is a pre-rendered, smoothly interpolated looping animation.
var SpiderMan = buildAnimation()

func buildAnimation() []string {
	const stepsPerMove = 5
	var result []string
	for i := 0; i < len(keyPoses); i++ {
		a := keyPoses[i]
		b := keyPoses[(i+1)%len(keyPoses)]
		for step := 0; step < stepsPerMove; step++ {
			t := float64(step) / stepsPerMove
			p := mixPose(a, b, t)
			// Small rhythmic bob keeps the stance alive between larger gestures.
			bob := math.Sin(t*math.Pi*2) * .35
			p.head.y += bob
			p.shoulderL.y += bob
			p.shoulderR.y += bob
			p.hipL.y += bob * .4
			p.hipR.y += bob * .4
			result = append(result, render(p, len(result)))
		}
	}
	return result
}

// FrameCount reports the number of rendered frames (useful in tests/tools).
func FrameCount() int { return len(SpiderMan) }

// FrameAt returns a frame, wrapping indexes to make looping easy.
func FrameAt(index int) string {
	if len(SpiderMan) == 0 {
		return fmt.Sprint("animation unavailable")
	}
	return SpiderMan[index%len(SpiderMan)]
}
