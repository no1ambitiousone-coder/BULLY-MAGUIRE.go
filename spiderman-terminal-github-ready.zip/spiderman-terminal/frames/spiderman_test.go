package frames

import (
	"strings"
	"testing"
)

func TestSpiderManAnimationHasMultipleRenderedFrames(t *testing.T) {
	if FrameCount() < 24 {
		t.Fatalf("expected at least 24 interpolated frames, got %d", FrameCount())
	}
	if !strings.Contains(FrameAt(0), "\x1b[") {
		t.Fatal("expected ANSI colour sequences in rendered frame")
	}
	if FrameAt(FrameCount()) != FrameAt(0) {
		t.Fatal("FrameAt should wrap to the first frame")
	}
}
