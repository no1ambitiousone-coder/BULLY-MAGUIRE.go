# Spider-Man Black Suit Dance — curl animation server

A small Go HTTP server that streams a looping, ANSI-coloured ASCII dance to a terminal. It follows the same broad architecture as curl-based animation sites: an HTTP route continuously streams pre-rendered frames, and `curl` displays them in the terminal.

The character and dance are an original ASCII interpretation. They are not traced or extracted frames from *Spider-Man 3*.

## Run locally

Requires Go 1.22 or newer.

```bash
go run .
```

In a second terminal:

```bash
curl -N http://localhost:8080/spiderman
```

On Windows CMD, use:

```cmd
curl.exe -N http://localhost:8080/spiderman
```

Press `Ctrl+C` to stop the stream.

## Routes

- `/spiderman`
- `/spider-man`
- `/black-suit-dance`

## Deploy

The included Dockerfile builds a small, static Go server. Deploy this repository to any container host that supports Docker and set/expose port `8080` (or allow the host to provide `PORT`).

Once deployed, run:

```bash
curl -N https://YOUR-HOST/spiderman
```

The `-N` option disables curl's output buffering so frames appear as they arrive.

## GitHub setup

1. Create a new GitHub repository, for example `spiderman-terminal-dance`.
2. Upload `main.go`, `go.mod`, the `frames/` folder, `Dockerfile`, and `README.md`.
3. Commit the files.
4. Deploy the repository as a Docker web service.

GitHub stores the source code; it does not itself run the always-on HTTP stream. A deployed server is needed for a public URL.

## Tune the animation

- Change `frameDelay` in `main.go` to alter playback speed.
- Edit the key poses in `frames/spiderman.go` to change the dance.
- Change `stepsPerMove` in `frames/spiderman.go` to increase or reduce interpolation smoothness.
