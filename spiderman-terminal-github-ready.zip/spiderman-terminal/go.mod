module spiderman-terminal

go 1.22
